// Utility functions
